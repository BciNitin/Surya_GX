﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class QualityChecks
    {
        public List<InwardOrderForQC> GetInwardOrderForQCs(InwardOrderForQCSearchCriteria criteria)
        {
            var factory = new QCFactory();
            return factory.FetchInwardOrders(criteria);
        }

        public string ValidateMaterial(string code, int plantId)
        {
            var factory = new QCFactory();
            return factory.ValidateMaterial(code, plantId);
        }


        public List<QCReportEntries> GetInventerysForReport(QCReportEntriesSearchCriteria criteria)
        {
            var dal = new QCFactory();
            return dal.FetchInventorysForReport(criteria);
        }
        //public List<InwardOrder> GetRequisitionOrders(InwardOrderSearchCriteria criteria)
        //{
        //    var factory = new QCFactory();
        //    return factory.FetchRequisitionOrders(criteria);
        //}

        //public List<InwardOrder> GetVendorReturnOrders(InwardOrderSearchCriteria criteria)
        //{
        //    var factory = new QCFactory();
        //    return factory.FetchVendorReturnOrders(criteria);
        //}

        public InwardOrderForQC GetInwardOrder(long InwardOrderId, int forQCorStore)
        {
            CodeContract.Required<ArgumentException>(InwardOrderId > 0, "InwardOrder Id is madatory");
            var factory = new QCFactory();

            return factory.Fetch(InwardOrderId, forQCorStore);
        }

        //public InwardOrder Save(InwardOrder InwardOrder)
        //{
        //    CodeContract.Required<ArgumentException>(InwardOrder != null, "InwardOrder Id should not be null");
        //    InwardOrder.Validate();
        //    var factory = new QCFactory();
        //    if (InwardOrder.Id > 0)
        //    {
        //        return factory.Update(InwardOrder);
        //    }
        //    else
        //    {
        //        return factory.Insert(InwardOrder);
        //    }
        //}

        public void DeleteInwardOrder(long InwardOrderId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(InwardOrderId > 0, "InwardOrder Id is madatory");
            var factory = new QCFactory();
            factory.Delete(InwardOrderId, deletedBy);
        }

        public List<KeyValue<long, string>> GetGRNNos(InwardOrderSearchCriteria criteria)
        {
            var factory = new QCFactory();
            return factory.FetchGRNNos(criteria);
        }

        public List<KeyValue<long, string>> GetGRNNosWhoseQCNotDone(InwardOrderForQCSearchCriteria criteria)
        {
            var factory = new QCFactory();
            return factory.FetchGRNNosWhoseQCNotDone(criteria);
        }

        public string SaveQC(QualityStatusInfo quality)
        {
            var factory = new QCFactory();
            return factory.SaveQC(quality);
        }
    }
}