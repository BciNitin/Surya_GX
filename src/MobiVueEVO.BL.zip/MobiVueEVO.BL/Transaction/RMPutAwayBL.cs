﻿using MobiVueEVO.DAL;
using System;
using System.Data;
using System.Threading.Tasks;

namespace MobiVueEVO.BL
{
    public class RMPutAwayBL
    {
        private readonly RMPutawayDL dlobj;
        public RMPutAwayBL()
        {
            dlobj = new RMPutawayDL();
        }

        public async Task<DataTable> ValidateLocation(string Location)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.ValidateLocation(Location);
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }

        public async Task<DataTable> PutawayAndValidateBarcode(string Location, string barCode)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.PutawayAndValidateBarcode(Location, barCode);
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }
    }
}