﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class PalletMerges
    {
        public List<KeyValue<long, string>> GetUsers(int siteId)
        {
            var factory = new PalletMergeFactory();
            return factory.FetchUsers(siteId);
        }
        public List<PalletMergeReport> GetPalletMergeReport(PalletMergeReportSearchCriteria criteria)
        {
            var factory = new PalletMergeFactory();
            return factory.FetchInwardOrders(criteria);
        }

        public string SavePutaway(PutawayInfo putaway)
        {
            var factory = new PalletMergeFactory();
            return factory.SavePutaway(putaway);
        }

        public string ValidateLocation(string code, int plantId)
        {
            var factory = new PalletMergeFactory();
            return factory.ValidateLocation(code, plantId);
        }

        public string SavePutawayPacking(PalletMerge putaway)
        {
            var factory = new PalletMergeFactory();
            return factory.SavePutawayPackingReceiving(putaway);
        }
        public string ValidateMaterial(string code, int plantId)
        {
            var factory = new PalletMergeFactory();
            return factory.ValidateMaterial(code, plantId);
        }
    }
}