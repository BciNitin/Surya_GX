﻿using MobiVueEVO.DAL.Transaction;
using System;
using System.Data;
using System.Threading.Tasks;

namespace MobiVueEVO.BL.Transaction
{
    public class MasterPrintLabelBL
    {
        private readonly MasterPrintLabelDL dlobj;
        public MasterPrintLabelBL()
        {
            dlobj = new MasterPrintLabelDL();
        }

        public async Task<DataTable> GetPRN(string labelType)
        {
            DataTable dt;
            try
            {
                dt = await dlobj.GetPRN(labelType);
            }
            catch (Exception)
            {
                throw;
            }

            return dt;
        }

        public async Task<DataTable> GetPRNDetail(string labelType)
        {
            DataTable dt;
            try
            {
                dt = await dlobj.GetPRNDetail(labelType);
            }
            catch (Exception)
            {
                throw;
            }

            return dt;
        }

        public async Task<DataTable> GetPRNDetail(string labelType, DataTable utLabelIds)
        {
            DataTable dt;
            try
            {
                dt = await dlobj.GetPRNDetail(labelType, utLabelIds);
            }
            catch (Exception)
            {
                throw;
            }

            return dt;
        }
    }
}
