﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVUE.Inventory.BL
{
    public class PickLists
    {
        public List<PickList> GetPickLists(PickListSearchCriteria criteria)
        {
            var factory = new PickListFactory();
            return factory.Fetchpicklists(criteria);
        }

        public PickList GetPickList(long PickListId)
        {
            CodeContract.Required<ArgumentException>(PickListId > 0, "Order Id is madatory");
            var factory = new PickListFactory();

            return factory.Fetch(PickListId);
        }

        public List<RMPickOrder> GetRMPickOrders(RMPickrderSearchCriteria criteria)
        {
            CodeContract.Required<ArgumentException>(criteria.IsNotNull(), "Criteria is madatory");
            var factory = new PickListFactory();

            return factory.FetchRMPickOrders(criteria);
        }

        public RMPickOrder GetRMPickOrder(long rmPickOrderId)
        {
            CodeContract.Required<ArgumentException>(rmPickOrderId > 0, "Order id is madatory");
            var factory = new PickListFactory();

            return factory.FetchRMPickOrder(rmPickOrderId);
        }

        public PickList Save(PickList pick)
        {
            CodeContract.Required<ArgumentException>(pick != null, "Order Id should not be null");
            pick.Validate();
            var factory = new PickListFactory();
            if (pick.Id > 0)
            {
                return factory.Update(pick);
            }
            else
            {
                return factory.Insert(pick);
            }
        }

        public string GeneratePicklist(long orderId)
        {
            var factory = new PickListFactory();
            return factory.PickListGeneration(orderId);
        }

        public void DeletePickList(long pickId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(pickId > 0, "Order Id is madatory");
            var factory = new PickListFactory();
            factory.Delete(pickId, deletedBy);
        }

        public List<KeyValue<long, string>> GetPicklistNos(PickListSearchCriteria criteria)
        {
            var factory = new PickListFactory();
            return factory.FetchPicklists(criteria);
        }

        public List<RMPickOrderItem> GetRMPickOrderItems(long orderid)
        {
            CodeContract.Required<ArgumentException>(orderid > 0, "Criteria is madatory");
            var factory = new PickListFactory();

            return factory.GetRMPickItemsByOrderId(orderid);
        }

        public List<PickListItem> GetPickItemsBypickId(long orderid)
        {
            CodeContract.Required<ArgumentException>(orderid > 0, "Criteria is madatory");
            var factory = new PickListFactory();

            return factory.GetPickItemsBypickId(orderid);
        }

        //RS
        public List<KeyValue<long, string>> GetPickPalletOrders(PickListSearchCriteria criteria)
        {
            var factory = new PickListFactory();
            return factory.FetchPickPalletOrders(criteria);
        }

        public string GetPalletByCode(string code, int plantId, long picklistid)
        {
            var factory = new PickListFactory();
            return factory.GetValidPallet(code, plantId, picklistid);
        }
    }
}