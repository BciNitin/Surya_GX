﻿using MobiVueEVO.DAL;
using System;
using System.Data;
using System.Threading.Tasks;

namespace MobiVueEVO.BL
{
    public class RMJobworkBL
    {
        private readonly RMJobworkDL dlobj;
        public RMJobworkBL()
        {
            dlobj = new RMJobworkDL();
        }

        public async Task<DataTable> GetIssueSlipNo()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetIssueSlipNo();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> GetItemCode(string issueSlipNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetItemCode(issueSlipNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> GetItemLineNo(string issueSlipNo, string itemNumber)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetItemLineNo(issueSlipNo, itemNumber);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> GetGridDetail(string issueSlipNo, string itemNo, string itemLineNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetGridDetail(issueSlipNo, itemNo, itemLineNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> SaveJobWork(string issueSlipNo, string itemNo, string itemLineNo,
            string barCode, string location)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.SaveJobWork(issueSlipNo, itemNo, itemLineNo, barCode, location);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }
    }
}
