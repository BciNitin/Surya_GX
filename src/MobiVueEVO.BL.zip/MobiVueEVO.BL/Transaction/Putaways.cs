﻿using MobiVueEVO.BO;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL
{
    public class Putaways
    {
        public string SavePutaway(PutawayInfo putaway)
        {
            var factory = new PutawayFactory();
            return factory.SavePutaway(putaway);
        }

        public string ValidateLocation(string code, int plantId)
        {
            var factory = new PutawayFactory();
            return factory.ValidateLocation(code, plantId);
        }

        public string SavePutawayPacking(PutawayPackingInfo putaway)
        {
            var factory = new PutawayFactory();
            return factory.SavePutawayPackingReceiving(putaway);
        }
        public string ValidateMaterial(string code, int plantId)
        {
            var factory = new PutawayFactory();
            return factory.ValidateMaterial(code, plantId);
        }
    }
}