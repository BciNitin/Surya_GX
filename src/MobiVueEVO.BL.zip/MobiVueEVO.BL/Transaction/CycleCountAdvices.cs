﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;


namespace MobiVUE.Inventory.BL
{
    public class CycleCountAdvices
    {
        public List<CycleCountAdvice> GetAdviceNames(CycleCountAdviceSearchCriteria criteria)
        {
            var factory = new CycleCountAdviceFactory();
            return factory.FetchAdviceNames(criteria);
        }

        public CycleCountAdvice Get(long GRNOrderId)
        {
            CodeContract.Required<ArgumentException>(GRNOrderId > 0, "Order Id is madatory");
            var factory = new CycleCountAdviceFactory();

            return factory.FetchByCycleCountAdviceId(GRNOrderId);
        }
        public List<CycleCountAdvice> GetCycleCountAdvices(CycleCountAdviceSearchCriteria criteria)
        {
            // CodeContract.Required<ArgumentException>(GRNOrderId > 0, "Order Id is madatory");
            var factory = new CycleCountAdviceFactory();

            return factory.FetchCycleCountAdvices(criteria);
        }
        public List<CycleCountAdviceItem> GetItemByAdviceItemId(long itemId)
        {
            // CodeContract.Required<ArgumentException>(GRNOrderId > 0, "Order Id is madatory");
            var factory = new CycleCountAdviceFactory();

            return factory.GetItemsByAdviceItemId(itemId);
        }

        public CycleCountAdvice Save(CycleCountAdvice CycleCountAdvice)
        {
            CodeContract.Required<ArgumentException>(CycleCountAdvice != null, "CycleCountAdvice should not be null");
            CycleCountAdvice.Validate();
            var factory = new CycleCountAdviceFactory();
            if (CycleCountAdvice.CycleCountAdviceId > 0)
            {
                return factory.Update(CycleCountAdvice);
            }
            else
            {
                return factory.Insert(CycleCountAdvice);
            }
        }

        public void Delete(long OrderId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(OrderId > 0, "Order Id is madatory");
            var factory = new CycleCountAdviceFactory();
            factory.Delete(OrderId, deletedBy);
        }

        public List<KeyValue<long, string>> GetGRNNos(CycleCountAdviceSearchCriteria criteria)
        {
            var factory = new CycleCountAdviceFactory();
            return factory.FetchGRNNos(criteria);
        }
    }
}