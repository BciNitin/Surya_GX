﻿using Common;
using MobiVueEVO.DAL;
using System;
using System.Data;
using System.Threading.Tasks;

namespace MobiVueEVO.BL
{
    public class RMQualityCheckBL
    {
        private readonly RMQualityCheckDL dlboj;
        public RMQualityCheckBL()
        {
            dlboj = new RMQualityCheckDL();
        }

        public async Task<DataTable> GetGRNNo()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetGRNNo();
                if (dt.Rows.Count > 0)
                {
                    dt = dt;
                }
                else
                {
                    //sBarcodeResult = "N~No result found for scanned barcode";
                }
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                //sBarcodeResult = "ERROR~" + ex.Message.ToString();
            }
            return dt;
        }

        public async Task<DataTable> BindInventoryDetail(string sGRNNo)
        {
             DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.BindInventoryDetail(sGRNNo);
                //if (dt.Rows.Count > 0)
                //{
                //    dt = dt;
                //}
                //else
                //{
                //    //sBarcodeResult = "N~No result found for scanned barcode";
                //}
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                //sBarcodeResult = "ERROR~" + ex.Message.ToString();
            }
            return dt;
        }

        public async Task<DataTable> SCANBARCODEBindInventoryDetail(string sGRNNo, string ItemNO)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.SCANBARCODEBindInventoryDetail(sGRNNo,ItemNO);
                //if (dt.Rows.Count > 0)
                //{
                //    dt = dt;
                //}
                //else
                //{
                //    //sBarcodeResult = "N~No result found for scanned barcode";
                //}
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                //sBarcodeResult = "ERROR~" + ex.Message.ToString();
            }
            return dt;
        }


        
        public async Task<DataTable> SaveQualityCheckFullBatch(string type, int status,
             string sGRNNo, DataTable sItemNo, string sRemarks, bool isFullBatch)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.SaveQualityCheckFullBatch(type,  status,
              sGRNNo,  sItemNo,  sRemarks, isFullBatch);
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }

        public async Task<DataTable> GetItemDetail(DataTable dtItemNos, string sGRNNo)
        {
            DataTable dt;
            try
            {
                dt = await dlboj.GetItemDetail(dtItemNos, sGRNNo);
            }
            catch (Exception)
            {
                throw;
            }

            return dt;
        }
    }
}
