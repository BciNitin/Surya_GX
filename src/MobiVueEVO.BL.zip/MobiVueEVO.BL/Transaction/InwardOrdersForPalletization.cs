﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class InwardOrdersForPalletization
    {
        public List<InwardOrder> GetInwardOrders(InwardOrderSearchCriteria criteria)
        {
            var factory = new InwardOrderFactoryForPalletizaiton();
            return factory.FetchInwardOrders(criteria);
        }

        public List<InwardOrder> GetRequisitionOrders(InwardOrderSearchCriteria criteria)
        {
            var factory = new InwardOrderFactoryForPalletizaiton();
            return factory.FetchRequisitionOrders(criteria);
        }

        public List<InwardOrder> GetVendorReturnOrders(InwardOrderSearchCriteria criteria)
        {
            var factory = new InwardOrderFactoryForPalletizaiton();
            return factory.FetchVendorReturnOrders(criteria);
        }

        public InwardOrder GetInwardOrder(long InwardOrderId)
        {
            CodeContract.Required<ArgumentException>(InwardOrderId > 0, "InwardOrder Id is madatory");
            var factory = new InwardOrderFactoryForPalletizaiton();

            return factory.Fetch(InwardOrderId);
        }

        public InwardOrder Save(InwardOrder InwardOrder)
        {
            CodeContract.Required<ArgumentException>(InwardOrder != null, "InwardOrder Id should not be null");
            InwardOrder.Validate();
            var factory = new InwardOrderFactoryForPalletizaiton();
            if (InwardOrder.Id > 0)
            {
                return factory.Update(InwardOrder);
            }
            else
            {
                return factory.Insert(InwardOrder);
            }
        }

        public void DeleteInwardOrder(long InwardOrderId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(InwardOrderId > 0, "InwardOrder Id is madatory");
            var factory = new InwardOrderFactoryForPalletizaiton();
            factory.Delete(InwardOrderId, deletedBy);
        }

        public List<KeyValue<long, string>> GetGRNNos(InwardOrderSearchCriteria criteria)
        {
            var factory = new InwardOrderFactoryForPalletizaiton();
            return factory.FetchGRNNos(criteria);
        }

        public string SaveQC(QualityStatusInfo quality)
        {
            var factory = new InwardOrderFactoryForPalletizaiton();
            return factory.SaveQC(quality);
        }

        public string PalletValidation(string code, int plantId)
        {
            var factory = new InwardOrderFactoryForPalletizaiton();
            return factory.GetValidPallet(code, plantId);
        }
    }
}