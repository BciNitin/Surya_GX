﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class CycleCounts
    {
        public string SaveCycleCounts(CycleCount cyclecount)
        {
            var factory = new CycleCountFactory();
            return factory.SaveCycleCount(cyclecount);
        }

        public CycleCount GetCycleCounts(long cycleCountAdviceId)
        {
            CodeContract.Required<ArgumentException>(cycleCountAdviceId.IsNotNull(), "Cycle Count Advice Id is madatory");
            var factory = new CycleCountFactory();

            return factory.GetAllCycleCount(cycleCountAdviceId);
        }

        public string ValidateLocations(string locationCode, int plantId, long cycleCountAdviceId)
        {
            CodeContract.Required<ArgumentException>(cycleCountAdviceId.IsNotNull(), "Cycle Count Advice Id is madatory");
            CodeContract.Required<ArgumentException>(locationCode.IsNotNull(), "Location Code is madatory");
            var factory = new CycleCountFactory();
            return factory.ValidateLocation(locationCode, plantId, cycleCountAdviceId);
        }

        public string ValidatePallets(string palletCode, int plantId, long cycleCountAdviceId)
        {
            CodeContract.Required<ArgumentException>(cycleCountAdviceId.IsNotNull(), "Cycle Count Advice Id is madatory");
            CodeContract.Required<ArgumentException>(palletCode.IsNotNull(), "Pallet Code is madatory");
            var factory = new CycleCountFactory();
            return factory.ValidatePallet(palletCode, plantId, cycleCountAdviceId);
        }

        public List<KeyValue<short, string>> GetCycleCountAdviceNames(int plantId)
        {
            var factory = new CycleCountFactory();
            return factory.GetCycleCountAdviceNames(plantId);
        }
    }
}