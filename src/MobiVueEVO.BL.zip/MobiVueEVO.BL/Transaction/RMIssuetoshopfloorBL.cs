﻿using Common;
using MobiVueEVO.DAL;
using System;
using System.Data;

namespace MobiVueEVO.BL
{
    public class RMIssueToShopFloorBL
    {
        private readonly RMIssuetoshopfloorDL dlobj;
        public RMIssueToShopFloorBL()
        {
            dlobj = new RMIssuetoshopfloorDL();
        }

        public DataTable GetWORKORDERNO()
        {
            DataTable dtBindDetails = new DataTable();
            try
            {
                dtBindDetails = dlobj.GetWORKORDERNO();
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dtBindDetails;
        }
        public DataSet FETCHFGITEMCODE(string WORKORDERNO)
        {
            DataSet dtBindDetails = new DataSet();
            try
            {
                dtBindDetails = dlobj.FATCHFGITEMCODE(WORKORDERNO);
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dtBindDetails;
        }
        public DataTable GETVILIDATELOCATION(string _WORKORDERNO, string _ScanLocation)
        {

            DataTable dtBindDetails = new DataTable();
            try
            {
                dtBindDetails = dlobj.ValidateLocation(_WORKORDERNO, _ScanLocation);
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }

            return dtBindDetails;
        }

        public DataTable sScanIssueBarcode(string _WORKORDERNO, string _FGItemCode, string _ScanLocation, string sPartBarcode
           )
        {
            DataTable dt = new DataTable();
            try                            
            {                              
                dt = dlobj.ValidateBarcode(_WORKORDERNO, _FGItemCode, _ScanLocation, sPartBarcode);
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtData, System.Reflection.Assembly.GetExecutingAssembly().GetName() + "::" + System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return dt;
        }
    }
}
