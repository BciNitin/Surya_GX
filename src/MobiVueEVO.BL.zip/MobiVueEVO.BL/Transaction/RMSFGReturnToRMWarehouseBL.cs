﻿using MobiVueEVO.CommonUtility.Global;
using MobiVueEVO.DAL;
using System;
using System.Data;
using System.Threading.Tasks;

namespace MobiVueEVO.BL
{
    public class RMSFGReturnToRMWarehouseBL
    {
        private readonly RMSFGReturnToRMWarehouseDL dlboj;

        public RMSFGReturnToRMWarehouseBL()
        {
            dlboj = new RMSFGReturnToRMWarehouseDL();
        }

        public async Task<DataTable> GetMaterialDocument()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetMaterialDocument();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }

        public async Task<DataTable> GetItemNo(string slipNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetItemNo(slipNo);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }

        public async Task<DataTable> GetItemLineNo(string slipNo, string itemNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetItemLineNo(slipNo, itemNo);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }

        public async Task<DataTable> SFGReturnToRMWarehouse(string slipNo, string itemNo,
            string location, string barcode)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.SFGReturnToRMWarehouse(slipNo, itemNo, location, barcode);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }

        //----
        public async Task<DataTable> RMPrintBarcode(string _MRNNo, string _Part_Barcode, string sScanBy,
            decimal dReturnQty, string sSiteCode, string _PartCode, string sWorkOrderNo, string sScanType,
            string sUserID, string sLineCode, string sRemarks)
        {
            string sResult = string.Empty;
            DataTable dt = new DataTable();
            try
            {
                DataTable dtGetPRN = await dlboj.GetPRN("RM");
                if (dtGetPRN.Rows.Count > 0)
                {
                    dt = await dlboj.PrintBarcodeLabel(_MRNNo, _Part_Barcode, sScanBy, dReturnQty,
                        sSiteCode, _PartCode, sWorkOrderNo, sScanType, sUserID, sLineCode, sRemarks);
                    if (dt.Rows.Count > 0)
                    {
                        string sPRN = string.Empty;
                        sResult = dt.Rows[0][0].ToString();
                        if (sResult.StartsWith($"SUCCESS~"))
                        {
                            if (sScanType == "RM")
                            {
                                string sPRNPrintingResult = string.Empty;
                                try
                                {
                                    sPRN = dtGetPRN.Rows[0][0].ToString();
                                    sPRNPrintingResult = dlboj.GetReturnPrintingDetails(sPRN, _MRNNo,
                                        _PartCode, sResult.Split('~')[2], dReturnQty, _Part_Barcode);
                                    if (sPRNPrintingResult.Length == 0)
                                    {
                                        sResult = "N~Qty updated but PRN Printing data not found.";
                                    }
                                    else
                                    {
                                        //sResult = await dlboj.PrintDataLabel(sPRNPrintingResult,
                                        //    sResult.Split('~')[2]);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(System.Reflection.Assembly
                                        .GetExecutingAssembly().GetName() + "::" +
                                        System.Reflection.MethodBase.GetCurrentMethod().Name,
                                        "N~quantity updated but : " + ex.Message);
                                }
                            }
                        }
                    }
                    else
                    {
                        sResult = "N~No result found table, Please try again.";
                    }
                }
                else
                {
                    sResult = "N~Prn not found.";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }


    }
}
