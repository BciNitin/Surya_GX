﻿using Common;
using MobiVueEVO.DAL;
using System;
using System.Data;
using System.Threading.Tasks;

namespace MobiVueEVO.BL
{
    public class RMSupplierReturnBL
    {
        private readonly RMSupplierReturnDL dlobj;
        public RMSupplierReturnBL()
        {
            dlobj = new RMSupplierReturnDL();
        }

        public async Task<DataTable> GetDocumentNo()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetDocumentNo();
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtData, System.Reflection.Assembly.GetExecutingAssembly().GetName() + "::" + System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> GetItemCode(string sDocumentNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetItemCode(sDocumentNo);
            }
            catch (Exception ex)
            {
                //PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtData, System.Reflection.Assembly.GetExecutingAssembly().GetName() + "::" + System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> GetItemLineNo(string sDocumentNo, string sItemCode)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetItemLineNo(sDocumentNo, sItemCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> GetOrderDetails(string sDocumentNo, string sItemCode, string sItemLineNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetOrderDetails(sDocumentNo, sItemCode, sItemLineNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> SaveSupplierReturnData(string sOrderNo, string sPartCode, string sLineNo,
            string sLocationCode, string sScannedBarcode, string UserID, string sSiteCode, string sLineCode)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.ValidateSupplierData(sOrderNo, sPartCode, sLineNo, sLocationCode,
                    sScannedBarcode, UserID, sSiteCode, sLineCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }
    }
}
