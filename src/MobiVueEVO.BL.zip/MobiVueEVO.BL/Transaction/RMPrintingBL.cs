﻿using Common;
using MobiVueEVO.BL.Common;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Threading.Tasks;

namespace MobiVueEVO.BL
{
    public class RMPrintingBL
    {
        private readonly RMPrintingDL dlobj;
        public RMPrintingBL()
        {
            dlobj = new RMPrintingDL();
        }

        public async Task<DataTable> GetGRN()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetGRN();
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }
        
            public async Task<DataTable> BindGRNLineNo(string sGRNNO)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.BindGRNLineNo(sGRNNO);
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dt;
        }
        public async Task<DataTable> BindGRNDetail(string sGRNNO, string GRNLineNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.BindGRNDetail(sGRNNO, GRNLineNo);
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dt;
        }

        public async Task<DataTable> GRNPrinting(string sGRNNO, string sDOCUMENTTYPE, string sRECEVINGTRANSACTION,
            string sGRPODATE, string sTRANSACTIONTYPE, string sGRNLINENO, decimal sGRNQTY, decimal sRemqty,
            string sSUPPLIERCODE, string sSUPPLIERNAME, string sBATCHNO, string sPONO, 
            string sITEMNO, string sPOLINENO, string sPOSCHEDULENO,int spacksize)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.SaveGRNPrinting(sGRNNO, sDOCUMENTTYPE, sRECEVINGTRANSACTION,
                sGRPODATE, sTRANSACTIONTYPE, sGRNLINENO, sGRNQTY, sRemqty, sSUPPLIERCODE, sSUPPLIERNAME,
                sBATCHNO, sPONO, sITEMNO, sPOLINENO, sPOSCHEDULENO, spacksize);
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }
        
             public async Task<DataTable> GetREMQTY(string sGRNNO, string sGRNLineNO)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetREMQTY(sGRNNO, sGRNLineNO);
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }
        public async Task<DataTable> GetPrintDetail(string sGRNNO, string sGRNLineNO)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlobj.GetPrintDetail(sGRNNO, sGRNLineNO);
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }

        #region GRN Label Printing Logic
        //Label Printing Logic
        public async Task<string> PrintGRNLabel(string sType, string GRNNO)
        {
            try
            {
                string chkPrinterStatus = string.Empty;
                DataTable dtPRN = await dlobj.GetPRN(sType);

                //if (!ValidatorUtility.IsDtValid(dtPRN))
                //{
                //    return false;
                //}

                string sPRN = dtPRN.Rows[0][0].ToString();

                DataTable dtPRNDetail = await dlobj.GetPRNDetail(GRNNO);

               
                string sFinalPRN = LabelPrinting.SubstitutePRNVariables(sPRN, dtPRNDetail);
              
                // Take list of sting variable 
                //add final prn in that
               // reutrn list of sting
               // var fileSaved = await LabelPrinting.SavePRNContentToFileAsync(sFinalPRN);

                return sFinalPRN;
            }
            catch (Exception ex)
            {
                PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
        }
        #endregion
    }
}