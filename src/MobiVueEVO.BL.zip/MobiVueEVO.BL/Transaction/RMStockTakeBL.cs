﻿using MobiVueEVO.DAL;
using System;
using System.Data;
using System.Threading.Tasks;

namespace MobiVueEVO.BL
{
    public class RMStockTakeBL
    {
        private readonly RMStockTakeDL dlboj;

        public RMStockTakeBL()
        {
            dlboj = new RMStockTakeDL();
        }
         
        public async Task<DataTable> GetItemNo()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetItemNo();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }
        public async Task<DataTable> GetZone()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetZone();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }
        public async Task<DataTable> GetLocation(string Location)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetLocation(Location);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }
        public async Task<DataTable> SaveFullStock(DataTable stockTakeModel)
        {
            DataTable dtPhysicalStock = new DataTable();
            try
            {
                dtPhysicalStock = await dlboj.SaveFullStock(stockTakeModel);
            }
            catch (Exception ex)
            {
                //  PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dtPhysicalStock;
        }
        public async Task<DataTable> GetPhysicalAdviceNo()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetPhysicalAdviceNo();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }
        public async Task<DataTable> GetPhysicalDetails(string AdviceNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetPhysicalDetails(AdviceNo);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }

        public async Task<DataTable> GetScanItem(string iTEMNO)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetScanItem(iTEMNO);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }


        public  DataTable GetPhysicalStock(string sStockArea, string sBarcode)
        {
            DataTable dtPhysicalStock = new DataTable();
             try
            {
                dtPhysicalStock = dlboj.GetPhysicalStock(sStockArea, sBarcode);
            }
            catch (Exception ex)
            {
                //  PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dtPhysicalStock;
        }

        public async Task<DataTable> SaveFullPhysicalStock(string AdviceNo, string MaterialCode,
          string ScanItem, string Systemqty, string PhysicalStock, string Remarks)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.SaveFullPhysicalStock(AdviceNo, MaterialCode, ScanItem, Systemqty,
                    PhysicalStock, Remarks);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }

        public async Task<DataTable> GetStockReconciliationDetails(string adviceNo)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = await dlboj.GetStockReconciliationDetails(adviceNo);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dt;
        }
        public async Task<DataTable> UpdateFullStockReconciliation(DataTable StockReconciliationModel)
        {
            DataTable dtReconciliationStock = new DataTable();
            try
            {
                dtReconciliationStock = await dlboj.UpdateFullStockReconciliation(StockReconciliationModel);
            }
            catch (Exception ex)
            {
                //  PCommon.mBcilLogger.LogMessage(BcilLib.EventNotice.EventTypes.evtError, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
            return dtReconciliationStock;
        }
        
    }
}
