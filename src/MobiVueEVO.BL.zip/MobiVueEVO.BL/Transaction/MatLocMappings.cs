﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class MatLocMappings
    {
        public MatLocMapping GetMatLocMapping(int MatLocMappingId)
        {
            var factory = new MatLocMappingFactory();
            return factory.Fetch(MatLocMappingId);
        }



        public DataList<MatLocMapping, long> GetMatLocMappings(MatLocMappingSearchCriteria criteria)
        {
            var factory = new MatLocMappingFactory();
            return factory.FetchAll(criteria);
        }

        public MatLocMapping SaveMatLocMapping(MatLocMapping MatLocMapping)
        {
            CodeContract.Required<ArgumentException>(MatLocMapping != null, "MatLocMapping should not be null");
            MatLocMapping.Validate();
            var factory = new MatLocMappingFactory();
            if (MatLocMapping.BayId > 0)
            {
                return factory.Update(MatLocMapping);
            }
            else
            {
                return factory.Insert(MatLocMapping);
            }
        }

        public void DeleteMatLocMapping(int MatLocMappingId, long deletedBy)
        {
            var factory = new MatLocMappingFactory();
            factory.Delete(MatLocMappingId, deletedBy);
        }

        public List<KeyValue<int, string>> GetUsers(int siteId)
        {
            var factory = new MatLocMappingFactory();
            return factory.FetchUsers(siteId);
        }


        public List<KeyValue<int, string>> GetZoneCategories(int siteId)
        {
            var factory = new MatLocMappingFactory();
            return factory.FetchZoneCategories(siteId);
        }


        //public List<MatLocMapping> SaveMatLocMappings(List<MatLocMapping> MatLocMappings)
        //{
        //    CodeContract.Required<ArgumentException>(MatLocMappings.Count > 0, "Atleast one MatLocMapping is required for save MatLocMapping ");
        //    List<MatLocMapping> items = new List<MatLocMapping>();
        //    MatLocMapping item = null;
        //    using (var scope = new System.Transactions.TransactionScope())
        //    {
        //        foreach (var _MatLocMapping in MatLocMappings)
        //        {
        //            var dal = new MatLocMappingFactory();
        //            if (_MatLocMapping.MatLocMappingId > 0)
        //            {
        //                item = dal.Update(_MatLocMapping);
        //            }
        //            else
        //            {
        //                item = dal.Insert(_MatLocMapping);
        //            }

        //            items.Add(item);
        //        }
        //        scope.Complete();
        //        return MatLocMappings;
        //    }
        //}
    }
}