﻿using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System.Data;
using System.Threading.Tasks;
using System;
using MobiVUE;

namespace MobiVueEVO.BL
{
    public class PrintPRNBL
    {
        private readonly PrintPRNDL dlobj;
        public PrintPRNBL()
        {
            dlobj = new PrintPRNDL();
        }

        public LabelToPrint FetchLabelToPrint(long labelToPrintId)
        {
            CodeContract.Required<ArgumentException>(labelToPrintId > 0, "Label to print id should not be null");

            var dal = new PrintPRNDL();
            return dal.Fetch(labelToPrintId);
        }

        public void DeleteLabelToPrint(long labelToPrintId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(labelToPrintId > 0, "Label to print id required for delete");

            var dal = new PrintPRNDL();
            dal.Delete(labelToPrintId, deletedBy);
        }

        public LabelToPrint Save(LabelToPrint labelToPrint)
        {
            CodeContract.Required<ArgumentException>(labelToPrint.IsNotNull(), "Label to print required for save");

            var dal = new PrintPRNDL();
            if (labelToPrint.ID > 0)
            {
                return dal.Update(labelToPrint);
            }
            else
            {
                return dal.Insert(labelToPrint);
            }
        }

        public LabelToPrint FetchLabelToPrint(string plant)
        {
            CodeContract.Required<ArgumentException>(plant.IsNotNullOrWhiteSpace(), "Plant is required to get the label to print");

            var dal = new PrintPRNDL();
            return dal.FetchLabelToPrintByPlant(plant);
        }
    }
}