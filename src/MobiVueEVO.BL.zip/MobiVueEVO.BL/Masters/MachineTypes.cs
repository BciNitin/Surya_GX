﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class MachineTypes
    {
        public DataList<MachineType, long> GetMachineTypes(MachineTypeSearchCriteria criteria)
        {
            var factory = new MachineTypeFactory();
            return factory.FetchMachineTypes(criteria);
        }

        public List<KeyValue<short, string>> GetMachineTypes(int siteId)
        {
            var factory = new MachineTypeFactory();
            return factory.FetchMachineTypes(siteId);
        }

        public MachineType GetMachineType(short MachineTypeId)
        {
            CodeContract.Required<ArgumentException>(MachineTypeId > 0, "Machine type Id is madatory");
            var factory = new MachineTypeFactory();
            return factory.Fetch(MachineTypeId);
        }

        public MachineType Save(MachineType MachineType)
        {
            CodeContract.Required<ArgumentException>(MachineType != null, "Machine type Id should not be null");
            MachineType.Validate();
            var factory = new MachineTypeFactory();
            if (MachineType.Id > 0)
            {
                return factory.Update(MachineType);
            }
            else
            {
                return factory.Insert(MachineType);
            }
        }

        public void DeleteMachineType(short MachineTypeId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(MachineTypeId > 0, "Machine type Id is madatory");
            var factory = new MachineTypeFactory();
            factory.Delete(MachineTypeId, deletedBy);
        }
        public List<KeyValue<short, string>> GetMachineType(int siteId)
        {
            var factory = new MachineTypeFactory();
            return factory.FetchMachineType(siteId);
        }
    }
}