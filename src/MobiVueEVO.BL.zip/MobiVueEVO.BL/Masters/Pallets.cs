﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class Pallets
    {
        public Pallet GetPallet(long palletId)
        {
            var factory = new PalletFactory();
            return factory.Fetch(palletId);
        }

        public int GetNoOfPalletsOnLocation(long locationId, long siteId)
        {
            var factory = new PalletFactory();
            return factory.FetchNoOfPalletOnLocation(locationId, siteId);
        }

        public DataList<Pallet, long> GetPallets(PalletSearchCriteria criteria)
        {
            var factory = new PalletFactory();
            return factory.FetchAll(criteria);
        }

        public Pallet SavePallet(Pallet pallet)
        {
            CodeContract.Required<ArgumentException>(pallet != null, "Pallet should not be null");
            pallet.Validate();
            var factory = new PalletFactory();
            if (pallet.PalletId > 0)
            {
                return factory.Update(pallet);
            }
            else
            {
                return factory.Insert(pallet);
            }
        }

        public void DeletePallet(long palletId, long deletedBy)
        {
            var factory = new PalletFactory();
            factory.Delete(palletId, deletedBy);
        }

        public List<Pallet> SavePallets(List<Pallet> pallets)
        {
            CodeContract.Required<ArgumentException>(pallets.Count > 0, "Atleast one Pallet is required for save Pallet ");
            List<Pallet> items = new List<Pallet>();
            Pallet item = null;
            using (var scope = new System.Transactions.TransactionScope())
            {
                foreach (var _pallet in pallets)
                {
                    var dal = new PalletFactory();
                    if (_pallet.PalletId > 0)
                    {
                        item = dal.Update(_pallet);
                    }
                    else
                    {
                        item = dal.Insert(_pallet);
                    }

                    items.Add(item);
                }
                scope.Complete();
                return pallets;
            }
        }
    }
}