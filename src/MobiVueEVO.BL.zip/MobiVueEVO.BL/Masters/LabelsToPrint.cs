﻿using MobiVUE;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class LabelsToPrint
    {
        public LabelToPrint FetchLabelToPrint(long labelToPrintId)
        {
            CodeContract.Required<ArgumentException>(labelToPrintId > 0, "Label to print id should not be null");

            var dal = new LabelToPrintFactory();
            return dal.Fetch(labelToPrintId);
        }

        public void DeleteLabelToPrint(long labelToPrintId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(labelToPrintId > 0, "Label to print id required for delete");

            var dal = new LabelToPrintFactory();
            dal.Delete(labelToPrintId, deletedBy);
        }

        public LabelToPrint Save(LabelToPrint labelToPrint)
        {
            CodeContract.Required<ArgumentException>(labelToPrint.IsNotNull(), "Label to print required for save");

            var dal = new LabelToPrintFactory();
            return dal.Insert(labelToPrint);
        }
    }
}