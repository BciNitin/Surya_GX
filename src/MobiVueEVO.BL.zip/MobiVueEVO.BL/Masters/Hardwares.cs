﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class Hardwares
    {
        public DataList<Hardware, long> GetHardwares(HardwareSearchCriteria criteria)
        {
            var factory = new HardwareFactory();
            return factory.FetchHardwares(criteria);
        }

        public Hardware GetHardware(short HardwareId)
        {
            CodeContract.Required<ArgumentException>(HardwareId > 0, "Hardware Id is madatory");
            var factory = new HardwareFactory();

            return factory.Fetch(HardwareId);
        }

        public Hardware Save(Hardware Hardware)
        {
            CodeContract.Required<ArgumentException>(Hardware != null, "Hardware Id should not be null");
            Hardware.Validate();
            var factory = new HardwareFactory();
            if (Hardware.Id > 0)
            {
                return factory.Update(Hardware);
            }
            else
            {
                return factory.Insert(Hardware);
            }
        }

        public void DeleteHardware(short HardwareId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(HardwareId > 0, "Hardware Id is madatory");
            var factory = new HardwareFactory();
            factory.Delete(HardwareId, deletedBy);
        }

        public List<KeyValue<int, string>> GetPrintingModules(int plantId)
        {
            var factory = new HardwareFactory();
            return factory.FetchPrintingModules(plantId);
        }
    }
}