﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class Bays
    {
        public Bay GetBay(int BayId)
        {
            var factory = new BayFactory();
            return factory.Fetch(BayId);
        }



        public DataList<Bay, long> GetBays(BaySearchCriteria criteria)
        {
            var factory = new BayFactory();
            return factory.FetchAll(criteria);
        }

        public Bay SaveBay(Bay Bay)
        {
            CodeContract.Required<ArgumentException>(Bay != null, "Bay should not be null");
            Bay.Validate();
            var factory = new BayFactory();
            if (Bay.BayId > 0)
            {
                return factory.Update(Bay);
            }
            else
            {
                return factory.Insert(Bay);
            }
        }

        public void DeleteBay(int BayId, long deletedBy)
        {
            var factory = new BayFactory();
            factory.Delete(BayId, deletedBy);
        }

        //public List<Bay> SaveBays(List<Bay> Bays)
        //{
        //    CodeContract.Required<ArgumentException>(Bays.Count > 0, "Atleast one Bay is required for save Bay ");
        //    List<Bay> items = new List<Bay>();
        //    Bay item = null;
        //    using (var scope = new System.Transactions.TransactionScope())
        //    {
        //        foreach (var _Bay in Bays)
        //        {
        //            var dal = new BayFactory();
        //            if (_Bay.BayId > 0)
        //            {
        //                item = dal.Update(_Bay);
        //            }
        //            else
        //            {
        //                item = dal.Insert(_Bay);
        //            }

        //            items.Add(item);
        //        }
        //        scope.Complete();
        //        return Bays;
        //    }
        //}
    }
}