﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class InwardOrderTypes
    {
        public InwardOrderType GetInwardOrderType(short inwardOrderTypeId)
        {
            CodeContract.Required<ArgumentException>(inwardOrderTypeId > 0, "Inward order type Id is required for get Quality check Type");

            var dal = new InwardOrderTypeFactory();
            return dal.Fetch(inwardOrderTypeId);
        }

        public DataList<InwardOrderType, long> GetInwardOrderTypes(InwardOrderTypeSearchCriteria criteria)
        {
            var dal = new InwardOrderTypeFactory();
            return dal.FetchAll(criteria);
        }

        public List<KeyValue<short, string>> GetInwardOrderTypeNames()
        {
            var dal = new InwardOrderTypeFactory();
            return dal.FetchInwardOrderTypeNames();
        }

        public InwardOrderType SaveInwardOrderType(InwardOrderType InwardOrderType)
        {
            CodeContract.Required<ArgumentException>(InwardOrderType != null, "Inward order type should not be null");
            InwardOrderType.Validate();
            var dal = new InwardOrderTypeFactory();
            if (InwardOrderType.InwardOrderTypeId > 0)
            {
                return dal.Update(InwardOrderType);
            }
            else
            {
                return dal.Insert(InwardOrderType);
            }
        }

        public void DeleteInwardOrderType(short InwardOrderTypeId, long modifiedBy)
        {
            CodeContract.Required<ArgumentException>(InwardOrderTypeId > 0, "Inward order type Id is required for delete");
            var dal = new InwardOrderTypeFactory();
            dal.Delete(InwardOrderTypeId, modifiedBy);
        }
    }
}