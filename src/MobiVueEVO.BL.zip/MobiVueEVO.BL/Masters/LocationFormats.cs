﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class LocationFormats
    {
        public DataList<LocationFormat, long> GetLocationFormats(LocationFormatSearchCriteria criteria)
        {
            var factory = new LocationFormatFactory();
            return factory.FetchAllCriteria(criteria);
        }

        public LocationFormat GetLocationFormat(short LocationFormatId)
        {
            CodeContract.Required<ArgumentException>(LocationFormatId > 0, "Location format Id is madatory");
            var factory = new LocationFormatFactory();
            return factory.Fetch(LocationFormatId);
        }

        public LocationFormat Save(LocationFormat LocationFormat)
        {
            CodeContract.Required<ArgumentException>(LocationFormat != null, "Location format Id should not be null");
            LocationFormat.Validate();
            var factory = new LocationFormatFactory();
            if (LocationFormat.Id > 0)
            {
                return factory.Update(LocationFormat);
            }
            else
            {
                return factory.Insert(LocationFormat);
            }
        }

        public void DeleteLocationFormat(short LocationFormatId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(LocationFormatId > 0, "Location format Id is madatory");
            var factory = new LocationFormatFactory();
            factory.Delete(LocationFormatId, deletedBy);
        }
    }
}