﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class MaterialTypes
    {
        public DataList<MaterialType, long> GetMaterialTypes(MaterialTypeSearchCriteria criteria)
        {
            var factory = new MaterialTypeFactory();
            return factory.FetchAll(criteria);
        }

        public MaterialType GetMaterialType(short MaterialTypeId)
        {
            CodeContract.Required<ArgumentException>(MaterialTypeId > 0, "Material type Id is madatory");
            var factory = new MaterialTypeFactory();
            return factory.Fetch(MaterialTypeId);
        }

        public MaterialType Save(MaterialType MaterialType)
        {
            CodeContract.Required<ArgumentException>(MaterialType != null, "Material type Id should not be null");
            MaterialType.Validate();
            var factory = new MaterialTypeFactory();
            if (MaterialType.Id > 0)
            {
                return factory.Update(MaterialType);
            }
            else
            {
                return factory.Insert(MaterialType);
            }
        }

        public void DeleteMaterialType(short MaterialTypeId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(MaterialTypeId > 0, "Material type Id is madatory");
            var factory = new MaterialTypeFactory();
            factory.Delete(MaterialTypeId, deletedBy);
        }

        public List<KeyValue<short, string>> FetchMaterialType(int plantId)
        {
            // CodeContract.Required<ArgumentException>(plantId > 0, "Material type Id is madatory");
            var factory = new MaterialTypeFactory();
            return factory.FetchMaterialType(plantId);
        }
    }
}