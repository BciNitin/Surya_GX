﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO.Masters.Zone;
using MobiVueEVO.DAL.Masters.Zone;
using System;

namespace MobiVueEVO.BL.Masters
{
    public class ZoneCategories
    {
        public DataList<ZoneCategory, long> GetZoneCategories(ZoneCategorySearchCriteria criteria)
        {
            var factory = new ZoneCategoryFactory();
            return factory.FetchZoneCategories(criteria);
        }

        public ZoneCategory GetZoneCategory(int ZoneCategoryId)
        {
            CodeContract.Required<ArgumentException>(ZoneCategoryId > 0, "ZoneCategory Id is madatory");
            var factory = new ZoneCategoryFactory();
            return factory.Fetch(ZoneCategoryId);
        }

        public ZoneCategory Save(ZoneCategory ZoneCategory)
        {
            CodeContract.Required<ArgumentException>(ZoneCategory != null, "ZoneCategory Id should not be null");
            ZoneCategory.Validate();
            var factory = new ZoneCategoryFactory();
            if (ZoneCategory.Id > 0)
            {
                return factory.Update(ZoneCategory);
            }
            else
            {
                return factory.Insert(ZoneCategory);
            }
        }

        public void DeleteZoneCategory(int ZoneCategoryId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(ZoneCategoryId > 0, "ZoneCategory Id is madatory");
            var factory = new ZoneCategoryFactory();
            factory.Delete(ZoneCategoryId, deletedBy);
        }
    }
}