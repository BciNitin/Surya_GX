﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL.Masters
{
    public class SpoolTypes
    {
        public DataList<SpoolType, long> GetSpoolTypes(SpoolTypeSearchCriteria criteria)
        {
            var factory = new SpoolTypeFactory();
            return factory.FetchAll(criteria);
        }

        public SpoolType GetSpoolType(int SpoolTypeId)
        {
            CodeContract.Required<ArgumentException>(SpoolTypeId > 0, "SpoolType Id is madatory");
            var factory = new SpoolTypeFactory();
            return factory.Fetch(SpoolTypeId);
        }

        public SpoolType Save(SpoolType SpoolType)
        {
            CodeContract.Required<ArgumentException>(SpoolType != null, "SpoolType Id should not be null");
            SpoolType.Validate();
            var factory = new SpoolTypeFactory();
            if (SpoolType.Id > 0)
            {
                return factory.Update(SpoolType);
            }
            else
            {
                return factory.Insert(SpoolType);
            }
        }

        public void DeleteSpoolType(int SpoolTypeId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(SpoolTypeId > 0, "SpoolType Id is madatory");
            var factory = new SpoolTypeFactory();
            factory.Delete(SpoolTypeId, deletedBy);
        }

        public List<KeyValue<short, string>> GetSpoolTypes(int siteId)
        {
            var factory = new SpoolTypeFactory();
            return factory.FetchSpoolTypeNames(siteId);
        }

        public List<KeyValue<short, string>> GetUOMs(int siteId)
        {
            var factory = new SpoolTypeFactory();
            return factory.FetchUOMs(siteId);
        }
    }
}