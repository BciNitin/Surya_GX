﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class LocationTypes
    {
        public DataList<LocationType, long> GetLocationTypes(LocationTypeSearchCriteria criteria)
        {
            var factory = new LocationTypeFactory();
            return factory.FetchAll(criteria);
        }

        public LocationType GetLocationType(short LocationTypeId)
        {
            CodeContract.Required<ArgumentException>(LocationTypeId > 0, "Location type Id is madatory");
            var factory = new LocationTypeFactory();
            return factory.Fetch(LocationTypeId);
        }

        public LocationType Save(LocationType LocationType)
        {
            CodeContract.Required<ArgumentException>(LocationType != null, "Location type Id should not be null");
            LocationType.Validate();
            var factory = new LocationTypeFactory();
            if (LocationType.Id > 0)
            {
                return factory.Update(LocationType);
            }
            else
            {
                return factory.Insert(LocationType);
            }
        }

        public void DeleteLocationType(short LocationTypeId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(LocationTypeId > 0, "Location type Id is madatory");
            var factory = new LocationTypeFactory();
            factory.Delete(LocationTypeId, deletedBy);
        }
    }
}