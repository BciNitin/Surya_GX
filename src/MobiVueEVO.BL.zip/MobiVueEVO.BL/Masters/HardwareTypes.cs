﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class HardwareTypes
    {
        public DataList<HardwareType, long> GetHardwareTypes(HardwareTypeSearchCriteria criteria)
        {
            var factory = new HardwareTypeFactory();
            return factory.FetchHardwareTypes(criteria);
        }

        public List<KeyValue<short, string>> GetHardwareTypes(long siteId)
        {
            var factory = new HardwareTypeFactory();
            return factory.FetchHardwareTypes(siteId);
        }

        public HardwareType GetHardwareType(short HardwareTypeId)
        {
            CodeContract.Required<ArgumentException>(HardwareTypeId > 0, "HardwareType Id is madatory");
            var factory = new HardwareTypeFactory();
            return factory.Fetch(HardwareTypeId);
        }

        public HardwareType Save(HardwareType HardwareType)
        {
            CodeContract.Required<ArgumentException>(HardwareType != null, "HardwareType Id should not be null");
            HardwareType.Validate();
            var factory = new HardwareTypeFactory();
            if (HardwareType.Id > 0)
            {
                return factory.Update(HardwareType);
            }
            else
            {
                return factory.Insert(HardwareType);
            }
        }

        public void DeleteHardwareType(short HardwareTypeId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(HardwareTypeId > 0, "HardwareType Id is madatory");
            var factory = new HardwareTypeFactory();
            factory.Delete(HardwareTypeId, deletedBy);
        }
    }
}