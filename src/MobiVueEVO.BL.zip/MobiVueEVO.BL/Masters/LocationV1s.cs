﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO.Masters.Location;
using MobiVueEVO.DAL.Masters.Location;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL.Masters
{
    public class LocationV1s
    {
        public DataList<LocationV1, long> GetLocations(LocationV1SearchCriteria criteria)
        {
            var factory = new LocationV1Factory();
            return factory.FetchAll(criteria);
        }

        public LocationV1 GetLocation(int LocationId)
        {
            CodeContract.Required<ArgumentException>(LocationId > 0, "Location Id is madatory");
            var factory = new LocationV1Factory();
            return factory.Fetch(LocationId);
        }

        public LocationV1 Save(LocationV1 LocationV1)
        {
            CodeContract.Required<ArgumentException>(LocationV1 != null, "Location Id should not be null");
            LocationV1.Validate();
            var factory = new LocationV1Factory();
            if (LocationV1.Id > 0)
            {
                return factory.Update(LocationV1);
            }
            else
            {
                return factory.Insert(LocationV1);
            }
        }

        public void DeleteLocation(int LocationId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(LocationId > 0, "Location Id is madatory");
            var factory = new LocationV1Factory();
            factory.Delete(LocationId, deletedBy);
        }

        public List<KeyValue<short, string>> GetLocationTypes(int siteId)
        {
            var factory = new LocationV1Factory();
            return factory.FetchLocationTypes(siteId);
        }

        public List<KeyValue<int, string>> GetZones(int siteId)
        {
            var factory = new LocationV1Factory();
            return factory.FetchZones(siteId);
        }

        public List<KeyValue<short, string>> GetAttributes1(int siteId)
        {
            var factory = new LocationV1Factory();
            return factory.FetchAttributes1(siteId);
        }

        public List<KeyValue<short, string>> GetAttributes2(int siteId)
        {
            var factory = new LocationV1Factory();
            return factory.FetchAttributes2(siteId);
        }

        public List<KeyValue<short, string>> GetAttributes3(int siteId)
        {
            var factory = new LocationV1Factory();
            return factory.FetchAttributes3(siteId);
        }

        public List<KeyValue<short, string>> GetLocationFormats(int siteId)
        {
            var factory = new LocationV1Factory();
            return factory.FetchLocationFormats(siteId);
        }

        public List<KeyValue<short, string>> GetUOMs(int siteId)
        {
            var factory = new LocationV1Factory();
            return factory.FetchUOMs(siteId);
        }
    }
}