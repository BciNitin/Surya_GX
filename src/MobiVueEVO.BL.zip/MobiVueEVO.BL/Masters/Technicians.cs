﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class Technicians
    {
        public Technician GetTechnician(int TechnicianId)
        {
            var factory = new TechnicianFactory();
            return factory.Fetch(TechnicianId);
        }



        public DataList<Technician, long> GetTechnicians(TechnicianSearchCriteria criteria)
        {
            var factory = new TechnicianFactory();
            return factory.FetchAll(criteria);
        }

        public Technician SaveTechnician(Technician Technician)
        {
            CodeContract.Required<ArgumentException>(Technician != null, "Technician should not be null");
            Technician.Validate();
            var factory = new TechnicianFactory();
            if (Technician.BayId > 0)
            {
                return factory.Update(Technician);
            }
            else
            {
                return factory.Insert(Technician);
            }
        }

        public void DeleteTechnician(int TechnicianId, long deletedBy)
        {
            var factory = new TechnicianFactory();
            factory.Delete(TechnicianId, deletedBy);
        }

        public List<KeyValue<long, string>> GetUsers(int siteId)
        {
            var factory = new TechnicianFactory();
            return factory.FetchUsers(siteId);
        }


        public List<KeyValue<int, string>> GetZoneCategories(int siteId)
        {
            var factory = new TechnicianFactory();
            return factory.FetchZoneCategories(siteId);
        }


        //public List<Technician> SaveTechnicians(List<Technician> Technicians)
        //{
        //    CodeContract.Required<ArgumentException>(Technicians.Count > 0, "Atleast one Technician is required for save Technician ");
        //    List<Technician> items = new List<Technician>();
        //    Technician item = null;
        //    using (var scope = new System.Transactions.TransactionScope())
        //    {
        //        foreach (var _Technician in Technicians)
        //        {
        //            var dal = new TechnicianFactory();
        //            if (_Technician.TechnicianId > 0)
        //            {
        //                item = dal.Update(_Technician);
        //            }
        //            else
        //            {
        //                item = dal.Insert(_Technician);
        //            }

        //            items.Add(item);
        //        }
        //        scope.Complete();
        //        return Technicians;
        //    }
        //}
    }
}