﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class PalletTypes
    {
        public MobiVueEVO.BO.PalletTypes GetPallet(int palletId)
        {
            var factory = new Pallet_TypeFactory();
            return factory.Fetch(palletId);
        }

        //public int GetNoOfPalletTypesOnLocation(long locationId, long siteId)
        //{
        //    var factory = new Pallet_TypeFactory();
        //    return factory.FetchNoOfPalletOnLocation(locationId, siteId);
        //}

        public DataList<MobiVueEVO.BO.PalletTypes, long> GetPalletTypes(PalletTypeSearchCriteria criteria)
        {
            var factory = new Pallet_TypeFactory();
            return factory.FetchAll(criteria);
        }

        public MobiVueEVO.BO.PalletTypes SavePallet(MobiVueEVO.BO.PalletTypes pallet)
        {
            CodeContract.Required<ArgumentException>(pallet != null, "Pallet type should not be null");
            pallet.Validate();
            var factory = new Pallet_TypeFactory();
            if (pallet.PalletId > 0)
            {
                return factory.Update(pallet);
            }
            else
            {
                return factory.Insert(pallet);
            }
        }

        //public List<MobiVueEVO.BO.PalletTypes> GetPalletTypes()
        //{
        //    var dal = new Pallet_TypeFactory();
        //    return dal.FetchPalletTypes();
        //}


        public void DeletePallet(int palletId, long deletedBy)
        {
            var factory = new Pallet_TypeFactory();
            factory.Delete(palletId, deletedBy);
        }

        //public List<Pallet> SavePalletTypes(List<Pallet> PalletTypes)
        //{
        //    CodeContract.Required<ArgumentException>(PalletTypes.Count > 0, "Atleast one Pallet Type is required for save Pallet ");
        //    List<Pallet> items = new List<Pallet>();
        //    Pallet item = null;
        //    using (var scope = new System.Transactions.TransactionScope())
        //    {
        //        foreach (var _pallet in PalletTypes)
        //        {
        //            var dal = new Pallet_TypeFactory();
        //            if (_pallet.PalletId > 0)
        //            {
        //                item = dal.Update(_pallet);
        //            }
        //            else
        //            {
        //                item = dal.Insert(_pallet);
        //            }

        //            items.Add(item);
        //        }
        //        scope.Complete();
        //        return PalletTypes;
        //    }
        //}
    }
}