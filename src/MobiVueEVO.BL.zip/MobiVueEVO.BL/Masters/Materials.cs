﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class Materials
    {
        public DataList<MaterialLapp, long> GetMaterialMasters(MaterialSearchCriteria criteria)
        {
            var factory = new MaterialFactory();
            return factory.FetchMaterialMaster(criteria);
        }

        public MaterialLapp GetMaterialMaster(int Id)
        {
            // CodeContract.Required<ArgumentException>(Id > 0, "Material Id is madatory");
            var factory = new MaterialFactory();
            return factory.Fetch(Id);
        }

        public MaterialLapp Save(MaterialLapp MaterialMaster)
        {
            CodeContract.Required<ArgumentException>(MaterialMaster != null, "Material Id should not be null");
            MaterialMaster.Validate();
            var factory = new MaterialFactory();
            if (MaterialMaster.Id > 0)
            {
                return factory.Update(MaterialMaster);
            }
            else
            {
                return factory.Insert(MaterialMaster);
            }
        }

        public void DeleteMaterialMaster(int Id, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Material Id is madatory");
            var factory = new MaterialFactory();
            factory.Delete(Id, deletedBy);
        }
    }
}