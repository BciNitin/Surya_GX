﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL.Masters;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class Spools
    {
        public string bulkUpload(List<Spool> listbulk)
        {
            var factory = new SpoolFactory();
            return factory.BulkUploadLogic(listbulk);
        }
        public DataList<Spool, long> GetSpoolMasters(SpoolMasterSearchCriteria criteria)
        {
            var factory = new SpoolFactory();
            return factory.FetchAll(criteria);
        }
        public DataList<Spool, long> GetSpoolMastersForBulkCheck(SpoolMasterSearchCriteria criteria)
        {
            var factory = new SpoolFactory();
            return factory.FetchAllForBulkCheck(criteria);
        }

        public Spool GetSpoolMaster(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Spool Id is madatory");
            var factory = new SpoolFactory();
            return factory.Fetch(Id);
        }

        public Spool Save(Spool SpoolMaster)
        {
            CodeContract.Required<ArgumentException>(SpoolMaster != null, "Spool Id should not be null");
            SpoolMaster.Validate();
            var factory = new SpoolFactory();
            if (SpoolMaster.Id > 0)
            {
                return factory.Update(SpoolMaster);
            }
            else
            {
                return factory.Insert(SpoolMaster);
            }
        }

        public void DeleteSpoolMaster(int Id, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Spool Id is madatory");
            var factory = new SpoolFactory();
            factory.Delete(Id, deletedBy);
        }
    }
}