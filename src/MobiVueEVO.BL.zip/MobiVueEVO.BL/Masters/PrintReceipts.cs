﻿using MobiVUE;

using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class PrintReceipts
    {
        public PrintReceipt GetPrintReceipt(Int32 prnId)
        {
            CodeContract.Required<ArgumentException>(prnId > 0, "prn id required for get PrintReceipt");

            var dal = new PrintReceiptFactory();
            return dal.Fetch(prnId);
        }

        public PrintReceipt GetPrintReceipt(PrintReceiptSearchCriteria criteria)
        {
            var dal = new PrintReceiptFactory();
            return dal.Fetch(criteria);
        }

        public PrintReceipt SavePrintReceipt(PrintReceipt printReceipt)
        {
            CodeContract.Required<ArgumentException>(printReceipt != null, "PrintReceipt should not be null");

            var dal = new PrintReceiptFactory();

            if (printReceipt.IsNew)
                return dal.Insert(printReceipt);
            else
                return dal.Update(printReceipt);
        }
    }
}