﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class LAPPZones
    {
        public DataList<LAPPZone, long> GetLAPPZones(ZoneSearchCriteria criteria)
        {
            var factory = new ZoneFactory();
            return factory.FetchAll(criteria);
        }

        public LAPPZone GetLAPPZone(int LAPPZoneId)
        {
            CodeContract.Required<ArgumentException>(LAPPZoneId > 0, "LAPPZone Id is madatory");
            var factory = new ZoneFactory();
            return factory.Fetch(LAPPZoneId);
        }

        public LAPPZone Save(LAPPZone LAPPZone)
        {
            CodeContract.Required<ArgumentException>(LAPPZone != null, "LAPPZone Id should not be null");
            LAPPZone.Validate();
            var factory = new ZoneFactory();
            if (LAPPZone.Id > 0)
            {
                return factory.Update(LAPPZone);
            }
            else
            {
                return factory.Insert(LAPPZone);
            }
        }

        public void DeleteLAPPZone(int LAPPZoneId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(LAPPZoneId > 0, "LAPPZone Id is madatory");
            var factory = new ZoneFactory();
            factory.Delete(LAPPZoneId, deletedBy);
        }

        //public List<KeyValue<short, string>> GetLAPPZones(int siteId)
        //{
        //    var factory = new ZoneFactory();
        //    return factory.FetchLAPPZones(siteId);
        //}

        public List<KeyValue<int, string>> GetZoneCategories(int siteId)
        {
            var factory = new ZoneFactory();
            return factory.FetchZoneCategories(siteId);
        }

        //public List<KeyValue<short, string>> GetAttributes1(int siteId)
        //{
        //    var factory = new ZoneFactory();
        //    return factory.FetchAttributes1(siteId);
        //}

        //public List<KeyValue<short, string>> GetAttributes2(int siteId)
        //{
        //    var factory = new ZoneFactory();
        //    return factory.FetchAttributes2(siteId);
        //}

        //public List<KeyValue<short, string>> GetAttributes3(int siteId)
        //{
        //    var factory = new ZoneFactory();
        //    return factory.FetchAttributes3(siteId);
        //}

        //public List<KeyValue<short, string>> GetLAPPZoneFormats(int siteId)
        //{
        //    var factory = new ZoneFactory();
        //    return factory.FetchLAPPZoneFormats(siteId);
        //}

        //public List<KeyValue<short, string>> GetUOMs(int siteId)
        //{
        //    var factory = new ZoneFactory();
        //    return factory.FetchUOMs(siteId);
        //}
    }
}