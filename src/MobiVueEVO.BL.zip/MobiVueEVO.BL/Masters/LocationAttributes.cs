﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class LocationAttributes
    {
        public DataList<LocationAttribute, long> GetLocationAttributes(LocationAttributeSearchCriteria criteria)
        {
            var factory = new LocationAttributeFactory();
            return factory.FetchAll(criteria);
        }

        public LocationAttribute GetLocationAttribute(short LocationAttributeId)
        {
            CodeContract.Required<ArgumentException>(LocationAttributeId > 0, "Location attribute Id is madatory");
            var factory = new LocationAttributeFactory();
            return factory.Fetch(LocationAttributeId);
        }

        public LocationAttribute Save(LocationAttribute LocationAttribute)
        {
            CodeContract.Required<ArgumentException>(LocationAttribute != null, "Location attribute Id should not be null");
            LocationAttribute.Validate();
            var factory = new LocationAttributeFactory();
            if (LocationAttribute.LocationAttrId > 0)
            {
                return factory.Update(LocationAttribute);
            }
            else
            {
                return factory.Insert(LocationAttribute);
            }
        }

        public void DeleteLocationAttribute(short LocationAttributeId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(LocationAttributeId > 0, "Location attribute Id is madatory");
            var factory = new LocationAttributeFactory();
            factory.Delete(LocationAttributeId, deletedBy);
        }
    }
}