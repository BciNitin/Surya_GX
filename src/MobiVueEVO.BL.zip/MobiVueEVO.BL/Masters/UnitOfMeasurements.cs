﻿using MobiVUE;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class UnitOfMeasurements
    {
        public UnitOfMeasurement GetUnitOfMeasurement(long uomId)
        {
            CodeContract.Required<ArgumentException>(uomId > 0, "UOM Id is required for get UOM");

            var dal = new UomFactory();
            return dal.Fetch(uomId);
        }

        public List<UnitOfMeasurement> GetUnitOfMeasurements()
        {
            var dal = new UomFactory();
            return dal.FetchAll();
        }

        public UnitOfMeasurement SaveUnitOfMeasurement(UnitOfMeasurement UnitOfMeasurement)
        {
            CodeContract.Required<ArgumentException>(UnitOfMeasurement != null, "UOM should not be null");
            UnitOfMeasurement.Validate();
            var dal = new UomFactory();
            if (UnitOfMeasurement.UOMId > 0)
            {
                return dal.Update(UnitOfMeasurement);
            }
            else
            {
                return dal.Insert(UnitOfMeasurement);
            }
        }

        public void DeleteUnitOfMeasurement(long UnitOfMeasurementId)
        {
            CodeContract.Required<ArgumentException>(UnitOfMeasurementId > 0, "UOM Id is required for delete UOM");
            var dal = new UomFactory();
            dal.Delete(UnitOfMeasurementId);
        }
    }
}