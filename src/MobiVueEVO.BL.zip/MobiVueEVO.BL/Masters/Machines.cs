﻿using MobiVUE;
using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;
using System;

namespace MobiVueEVO.BL
{
    public class Machines
    {
        public DataList<Machine, long> GetMachines(MachineSearchCriteria criteria)
        {
            var factory = new MachineFactory();
            return factory.FetchMachines(criteria);
        }

        public Machine GetMachine(short MachineId)
        {
            CodeContract.Required<ArgumentException>(MachineId > 0, "Machine Id is madatory");
            var factory = new MachineFactory();
            return factory.Fetch(MachineId);
        }

        public Machine Save(Machine Machine)
        {
            CodeContract.Required<ArgumentException>(Machine != null, "Machine Id should not be null");
            Machine.Validate();
            var factory = new MachineFactory();
            if (Machine.Id > 0)
            {
                return factory.Update(Machine);
            }
            else
            {
                return factory.Insert(Machine);
            }
        }

        public void DeleteMachine(short MachineId, long deletedBy)
        {
            CodeContract.Required<ArgumentException>(MachineId > 0, "Machine Id is madatory");
            var factory = new MachineFactory();
            factory.Delete(MachineId, deletedBy);
        }
    }
}