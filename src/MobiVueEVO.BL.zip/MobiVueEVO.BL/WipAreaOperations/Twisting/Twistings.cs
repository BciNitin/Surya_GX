﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL
{
    public class Twistings
    {
        public string SaveTwisting(Twisting twisting)
        {
            var factory = new TwistingFactory();
            return factory.SaveTwisting(twisting);
        }

        public DataList<Twisting, long> GetTwistings(long technid)
        {
            var factory = new TwistingFactory();
            return factory.FetchTwisting(technid);
        }
    }
}