﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL
{
    public class Bunchings
    {
        public string SaveBunching(Bunching bunching)
        {
            var factory = new BunchingFactory();
            return factory.SaveBunching(bunching);
        }

        public DataList<Bunching, long> GetBunching(long technid)
        {
            var factory = new BunchingFactory();
            return factory.FetchBunching(technid);
        }
    }
}