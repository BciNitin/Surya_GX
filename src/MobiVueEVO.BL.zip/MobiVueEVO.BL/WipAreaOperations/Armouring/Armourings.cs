﻿using MobiVUE.Utility;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL.WipAreaOperations.Armouring
{
    public class Armourings
    {
        public string SaveArmourings(MobiVueEVO.BO.Armouring armuring)
        {
            var factory = new ArmouringFactory();
            return factory.SaveArmuring(armuring);
        }

        public DataList<MobiVueEVO.BO.Armouring, long> GetArmourings(long technid)
        {
            var factory = new ArmouringFactory();
            return factory.FetchArmouring(technid);
        }
    }
}