﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL
{
    public class Rewindings
    {
        public string SaveInsulation(Rewinding insulation)
        {
            var factory = new RewindingFactory();
            return factory.SaveRewinding(insulation);
        }

        public DataList<Rewinding, long> GetRewindings(long technid)
        {
            var factory = new RewindingFactory();
            return factory.FetchRewinding(technid);
        }
    }
}