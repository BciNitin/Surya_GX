﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL
{
    public class Tapings
    {
        public string SaveTaping(Taping insulation)
        {
            var factory = new TapingFactory();
            return factory.SaveTaping(insulation);
        }

        public DataList<Taping, long> GetTapings(long technid)
        {
            var factory = new TapingFactory();
            return factory.FetchTaping(technid);
        }
    }
}