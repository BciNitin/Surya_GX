﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.BO.Common;
using MobiVueEVO.DAL;
using System.Collections.Generic;

namespace MobiVueEVO.BL
{
    public class WireDrawings
    {
        public string SaveWireDwarings(WireDrawing wiredrawing)
        {
            var factory = new WireDrawingFactory();
            return factory.SaveWireDrawing(wiredrawing);
        }

        public short GetMachineId(string machineNo, int plantId)
        {
            var factory = new WireDrawingFactory();
            return factory.GetMachineNo(machineNo, plantId);
        }

        public int GetSpoolId(string spoolcode, int plantId)
        {
            var factory = new WireDrawingFactory();
            return factory.GetSpoolId(spoolcode, plantId);
        }

        public int GetPalletId(string palletcode, int plantId)
        {
            var factory = new WireDrawingFactory();
            return factory.GetPalletId(palletcode, plantId);
        }

        public List<KeyValue<short, string>> GetConstructions(int plantid, short machineid)
        {
            var factory = new WireDrawingFactory();
            return factory.GetConstruction(plantid, machineid);
        }

        public List<KeyValue<short, string>> GetMachines(int plantid, short machinetypeid)
        {
            var factory = new WireDrawingFactory();
            return factory.GetMachine(plantid, machinetypeid);
        }

        public List<KeyValue<long, string>> GetTechnicians(int processid)
        {
            var factory = new WireDrawingFactory();
            return factory.GetTechnician(processid);
        }

        public List<KeyValue<short, string>> GetIdleReasons(int plantid)
        {
            var factory = new WireDrawingFactory();
            return factory.GetIdleReason(plantid);
        }

        public Shift GetShift(int plantId)
        {
            var factory = new WireDrawingFactory();
            return factory.GetShift(plantId);
        }

        public DataList<WireDrawing, long> GetWireDrawings(long technid)
        {
            var factory = new WireDrawingFactory();
            return factory.FetchWireDrawing(technid);
        }
    }
}