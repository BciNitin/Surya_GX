﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL
{
    public class Sheathings
    {
        public string SaveSheathing(Sheathing sheathing)
        {
            var factory = new SheathingFactory();
            return factory.SaveSheathing(sheathing);
        }

        public DataList<Sheathing, long> GetSheathings(long technid)
        {
            var factory = new SheathingFactory();
            return factory.FetchSheathing(technid);
        }
    }
}