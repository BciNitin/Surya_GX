﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL
{
    public class Insulations
    {
        public string SaveInsulation(Insulation insulation)
        {
            var factory = new InsulationFactory();
            return factory.SaveInsulation(insulation);
        }

        public DataList<Insulation, long> GetInsulations(long technid)
        {
            var factory = new InsulationFactory();
            return factory.FetchInsulation(technid);
        }
    }
}