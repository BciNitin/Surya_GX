﻿using MobiVUE.Utility;
using MobiVueEVO.BO;
using MobiVueEVO.DAL;

namespace MobiVueEVO.BL
{
    public class Braidings
    {
        public string SaveBraidings(Braiding braiding)
        {
            var factory = new BraidingFactory();
            return factory.SaveBraiding(braiding);
        }

        public DataList<Braiding, long> GetBraidings(long technid)
        {
            var factory = new BraidingFactory();
            return factory.FetchBraiding(technid);
        }
    }
}